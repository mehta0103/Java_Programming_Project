package ExceptionPackage;

public class Jukebox_Exception extends Exception
{

    public Jukebox_Exception() {
        super();
    }

    public Jukebox_Exception(String message) {
        super(message);
    }


}
